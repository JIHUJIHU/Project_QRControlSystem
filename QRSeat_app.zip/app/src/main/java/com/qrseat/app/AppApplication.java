package com.qrseat.app;

import android.app.Application;

import com.qrseat.Utils;

public class AppApplication extends Application {
    @Override
    public void onTerminate() {
        super.onTerminate();
        Utils.ID = null;
    }
}
