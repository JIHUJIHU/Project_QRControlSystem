package com.qrseat.retrofit.interfaces;

import com.qrseat.retrofit.request.RegisterRequest;

import androidx.annotation.NonNull;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface Register {

    @NonNull
    @POST("join")
    Call<String> register(@Body RegisterRequest request);
}
