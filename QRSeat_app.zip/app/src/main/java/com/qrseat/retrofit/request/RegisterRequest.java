package com.qrseat.retrofit.request;

public class RegisterRequest {
    private final String id;
    private final String pw;
    private final String name;

    public RegisterRequest(String id, String pw, String name) {
        this.id = id;
        this.pw = pw;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getPw() {
        return pw;
    }

    public String getName() {
        return name;
    }
}
