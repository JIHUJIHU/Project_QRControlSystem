package com.qrseat.retrofit.interfaces;

import com.qrseat.retrofit.request.SeatRequest;
import com.qrseat.retrofit.response.SeatResponse;

import androidx.annotation.NonNull;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface Seat {

    @NonNull
    @POST("seat/{seat_id}")
    Call<SeatResponse> request(@Body SeatRequest request, @Path(value = "seat_id", encoded = true) String seatID);
}
