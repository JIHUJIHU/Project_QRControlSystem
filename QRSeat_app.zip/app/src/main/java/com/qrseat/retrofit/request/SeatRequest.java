package com.qrseat.retrofit.request;

public class SeatRequest {
    private final String id;

    public SeatRequest(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }
}
