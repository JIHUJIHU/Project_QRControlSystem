package com.qrseat.retrofit.interfaces;

import com.qrseat.retrofit.request.LoginRequest;
import com.qrseat.retrofit.response.LoginResponse;

import androidx.annotation.NonNull;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface Login {

    @NonNull
    @POST("login")
    Call<LoginResponse> login(@Body LoginRequest request);
}
