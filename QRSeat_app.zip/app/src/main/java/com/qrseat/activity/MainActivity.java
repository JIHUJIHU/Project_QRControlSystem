package com.qrseat.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.qrseat.R;
import com.qrseat.Utils;
import com.qrseat.retrofit.interfaces.Seat;
import com.qrseat.retrofit.request.SeatRequest;
import com.qrseat.retrofit.response.SeatResponse;

import java.net.HttpURLConnection;
import java.util.Objects;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    //CaptureActivity 용 Request 코드
    public static final int REQUEST_SEAT = 0x0000c0de;

    private Seat requestService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initRetrofit();

        startScannerActivity();
    }

    //스캐너 실행
    private void startScannerActivity() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(ScannerActivity.class);
        integrator.setRequestCode(REQUEST_SEAT);
        integrator.initiateScan();
    }

    //Retrofit 서비스 생성
    private void initRetrofit() {
        requestService = Utils.RETROFIT.create(Seat.class);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_SEAT && resultCode == Activity.RESULT_OK) {
            IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

            Call<SeatResponse> seatRequest =
                    requestService.request(new SeatRequest(Utils.ID.toString()), scanResult.getContents());

            seatRequest.enqueue(new SeatResponseCallback());
        } else {
            finish();
        }
    }


    //좌석 이용 신청 응답
    private class SeatResponseCallback implements Callback<SeatResponse> {

        @Override
        public void onResponse(Call<SeatResponse> call, Response<SeatResponse> response) {
            if (response.errorBody() != null) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, response.errorBody().toString(), Toast.LENGTH_SHORT).show());
                finish();
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_OK) {
                //승인 됨
                runOnUiThread(() -> Toast.makeText(MainActivity.this, getText(R.string.request_ok), Toast.LENGTH_LONG).show());
                finish();
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_PAYMENT_REQUIRED) {
                //거부 됨
                runOnUiThread(() -> Toast.makeText(MainActivity.this, getText(R.string.request_reject), Toast.LENGTH_SHORT).show());
                startScannerActivity();
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                //이미 사용 중
                runOnUiThread(() -> Toast.makeText(MainActivity.this, getText(R.string.error_already), Toast.LENGTH_SHORT).show());
                startScannerActivity();
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_NOT_FOUND) {
                //없는 (알 수 없는) 자리
                runOnUiThread(() -> Toast.makeText(MainActivity.this, getText(R.string.not_found_seat), Toast.LENGTH_SHORT).show());
                startScannerActivity();
            }
        }

        @Override
        public void onFailure(Call<SeatResponse> call, Throwable t) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show());
            t.printStackTrace();
            finish();
        }
    }
}
