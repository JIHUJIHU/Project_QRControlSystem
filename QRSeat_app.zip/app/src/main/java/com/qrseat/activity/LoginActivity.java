package com.qrseat.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.qrseat.R;
import com.qrseat.Utils;
import com.qrseat.interfaces.OnClickOnesListener;
import com.qrseat.retrofit.interfaces.Login;
import com.qrseat.retrofit.request.LoginRequest;
import com.qrseat.retrofit.response.LoginResponse;

import java.net.HttpURLConnection;
import java.util.Objects;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.HttpUrl;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * 로그인
 */
public class LoginActivity extends AppCompatActivity {

    public static final int REGISTER = 0;

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @BindView(R.id.layout_id)
    TextInputLayout inputLayoutID;

    @BindView(R.id.id)
    TextInputEditText inputEditTextID;

    @BindView(R.id.layout_password)
    TextInputLayout inputLayoutPW;

    @BindView(R.id.password)
    TextInputEditText inputEditTextPW;
    Login loginService;
    boolean isLogin = false;
    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);
        pref = getSharedPreferences("login", MODE_PRIVATE);

        inputEditTextID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (inputLayoutID.isErrorEnabled())
                    inputLayoutID.setError(null);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        inputEditTextPW.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (inputLayoutPW.isErrorEnabled())
                    inputLayoutPW.setError(null);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        findViewById(R.id.login).setOnClickListener(new OnClickOnesListener() {
            @Override
            public void onClickOnes(View v) {
                if (isLogin) return;

                boolean hasError = false;

                if (TextUtils.isEmpty(inputEditTextID.getText())) {
                    inputLayoutID.setError(getText(R.string.error_empty));
                    hasError = true;
                } else {
                    inputLayoutID.setError(null);
                }

                if (TextUtils.isEmpty(inputEditTextPW.getText())) {
                    inputLayoutPW.setError(getText(R.string.error_empty));
                    hasError = true;
                } else {
                    inputLayoutPW.setError(null);
                }

                if (hasError) return;

                isLogin = true;

                progressBar.setVisibility(View.VISIBLE);

                Call<LoginResponse> loginRequest =
                        loginService.login(new LoginRequest(inputEditTextID.getText().toString(), inputEditTextPW.getText().toString()));

                loginRequest.enqueue(new LoginResponseCallback());
            }
        });

        findViewById(R.id.register).setOnClickListener(new OnClickOnesListener() {
            @Override
            public void onClickOnes(View v) {
                startActivityForResult(new Intent(LoginActivity.this, RegisterActivity.class), REGISTER);
            }
        });

        findViewById(R.id.reset).setOnClickListener(new OnClickOnesListener() {
            @Override
            public void onClickOnes(View v) {
                showDialog();
            }
        });


        if (TextUtils.isEmpty(pref.getString("server", "")))
            showDialog();
        else
            initRetrofit(pref.getString("server", ""));
    }

    private void showDialog() {
        final LayoutInflater layoutInflater = LayoutInflater.from(this);
        @SuppressLint("InflateParams") final View view = layoutInflater.inflate(R.layout.dialog_edit, null);

        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(view);

        final TextView dialogTitleTextView = view.findViewById(R.id.tv_dialog_title);
        dialogTitleTextView.setText("서버 설정");

        final TextInputLayout textInputLayout = view.findViewById(R.id.text_input_dialog);

        final EditText editText = view.findViewById(R.id.text_input_edit_dialog);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (textInputLayout.isErrorEnabled()) {
                    textInputLayout.setErrorEnabled(false);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        AlertDialog alertDialog = alertDialogBuilder
                .setPositiveButton(android.R.string.ok, null)
                .setCancelable(false)
                .create();

        alertDialog.setOnShowListener(dialog -> alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String url = editText.getText().toString();
            HttpUrl check = HttpUrl.parse("http://" + url.replace("http://", "").replace(":8000", "") + ":8000");
            if (check == null) {
                textInputLayout.setError("주소 형식이 맞지 않음");
                return;
            }

            SharedPreferences.Editor editor = pref.edit();

            editor.putString("server", "http://" + url.replace("http://", "").replace(":8000", "") + ":8000");
            editor.apply();

            initRetrofit("http://" + url.replace("http://", "").replace(":8000", "") + ":8000");

            Call<LoginResponse> login = loginService.login(new LoginRequest("", ""));
            login.enqueue(new ResponseCallback());

            alertDialog.dismiss();
        }));
        alertDialog.show();
    }

    //Retrofit 서비스 생성
    private void initRetrofit(String url) {
        Utils.createRetrofit("http://" + url.replace("http://", "").replace(":8000", "") + ":8000");
        loginService = Utils.RETROFIT.create(Login.class);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REGISTER && resultCode == Activity.RESULT_OK) {
            Snackbar.make(getWindow().getDecorView(), getText(R.string.register_ok), Snackbar.LENGTH_SHORT).show();
        }
    }

    //로그인 응답
    private class LoginResponseCallback implements Callback<LoginResponse> {

        @Override
        public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
            isLogin = false;
            runOnUiThread(() -> progressBar.setVisibility(View.GONE));
            if (response.errorBody() != null) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, response.errorBody().toString(), Toast.LENGTH_SHORT).show();
                });

            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_OK) {
                Utils.ID = inputEditTextID.getText();
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, getText(R.string.error_id_pw), Toast.LENGTH_SHORT).show());
            } else {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show());

            }
        }

        @Override
        public void onFailure(Call<LoginResponse> call, Throwable t) {
            isLogin = false;
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(LoginActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show();
            });
            t.printStackTrace();
        }
    }

    //올바른 서버인지 확인
    private class ResponseCallback implements Callback<LoginResponse> {

        @Override
        public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
            if (response.errorBody() != null) {
                runOnUiThread(() -> {
                    Toast.makeText(LoginActivity.this, response.errorBody().toString(), Toast.LENGTH_SHORT).show();
                });

            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_OK) {
                //통신 완료
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, "연결 됨", Toast.LENGTH_SHORT).show());
            } else if (Objects.requireNonNull(response.body()).getStatus() == HttpURLConnection.HTTP_UNAUTHORIZED) {
                //통신 완료
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, "연결 됨", Toast.LENGTH_SHORT).show());
            } else {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show());
            }
        }

        @Override
        public void onFailure(Call<LoginResponse> call, Throwable t) {
            runOnUiThread(() -> Toast.makeText(LoginActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show());
            t.printStackTrace();
        }
    }
}
