package com.qrseat.activity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.qrseat.R;
import com.qrseat.Utils;
import com.qrseat.interfaces.OnClickOnesListener;
import com.qrseat.retrofit.interfaces.Register;
import com.qrseat.retrofit.request.RegisterRequest;

import java.util.Objects;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    @BindView(R.id.progressBar)
    ProgressBar progressBar;

    @BindView(R.id.layout_id)
    TextInputLayout inputLayoutID;

    @BindView(R.id.id)
    TextInputEditText inputEditTextID;

    @BindView(R.id.layout_password)
    TextInputLayout inputLayoutPW;

    @BindView(R.id.password)
    TextInputEditText inputEditTextPW;

    @BindView(R.id.layout_name)
    TextInputLayout inputLayoutNAME;

    @BindView(R.id.name)
    TextInputEditText inputEditTextNAME;

    Register registerService;
    boolean isRegistering = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);


        findViewById(R.id.register)
                .setOnClickListener(new OnClickOnesListener() {
            @Override
            public void onClickOnes(View v) {
                if (isRegistering) return;

                boolean hasError = false;

                if (TextUtils.isEmpty(inputEditTextID.getText())) {
                    inputLayoutID.setError(getText(R.string.error_empty));
                    hasError = true;
                } else {
                    inputLayoutID.setError(null);
                }

                if (TextUtils.isEmpty(inputEditTextPW.getText())) {
                    inputLayoutPW.setError(getText(R.string.error_empty));
                    hasError = true;
                } else {
                    inputLayoutPW.setError(null);
                }

                if (TextUtils.isEmpty(inputEditTextNAME.getText())) {
                    inputLayoutNAME.setError(getText(R.string.error_empty));
                    hasError = true;
                } else {
                    inputLayoutNAME.setError(null);
                }

                if (hasError) return;

                isRegistering = true;

                progressBar.setVisibility(View.VISIBLE);

                Call<String> registerRequest =
                        registerService.register(new RegisterRequest(inputEditTextID.getText().toString(), inputEditTextPW.getText().toString(), inputEditTextNAME.getText().toString()));

                registerRequest.enqueue(new RegisterResponseCallback());
            }
        });

        initRetrofit();
    }

    //Retrofit 서비스 생성
    private void initRetrofit() {
        registerService = Utils.RETROFIT.create(Register.class);
    }

    //가입 응답
    private class RegisterResponseCallback implements Callback<String> {

        @Override
        public void onResponse(Call<String> call, Response<String> response) {
            isRegistering = false;
            runOnUiThread(() -> progressBar.setVisibility(View.GONE));
            if (response.errorBody() != null) {
                runOnUiThread(() -> {
                    Toast.makeText(RegisterActivity.this, response.errorBody().toString(), Toast.LENGTH_SHORT).show();
                });

            } else if (Objects.requireNonNull(response.body()).contentEquals("회원가입 성공")) {
                setResult(RESULT_OK);
                finish();

            } else if (Objects.requireNonNull(response.body()).contentEquals("이미 존재하는 아이디")) {
                runOnUiThread(() -> Toast.makeText(RegisterActivity.this, "이미 존재하는 아이디입니다.",Toast.LENGTH_SHORT).show());
            } else {
                runOnUiThread(() -> Toast.makeText(RegisterActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show());
            }
        }

        @Override
        public void onFailure(Call<String> call, Throwable t) {
            isRegistering = false;
            runOnUiThread(() -> {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(RegisterActivity.this, getText(R.string.error), Toast.LENGTH_SHORT).show();
            });
            t.printStackTrace();
        }
    }
}
